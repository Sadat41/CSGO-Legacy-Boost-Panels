# Game-State Integration
This is used to programatically detect the current game score, team, etc. which is useful to check our status without having to OCR the actual round count from the screen.

Index.php is a simple web server that takes CS:GO Game State Integration updates. Install it and run in the background. Output.txt is created and read by AHK.

Install the .cfg to Steam/common/csgo/csgo/cfg
