# vboost-csgo
Automated Script for (now defunct) Competitive Boosting
