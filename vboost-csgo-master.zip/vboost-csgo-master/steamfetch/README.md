# SteamFetch
A very simple PHP program that fetches the "Join Game" URL of a steam user. The bot asks this program to get the URL of the lobby prior to joining on the clients.

This could be integrated automatically via AHK, but I didn't want to deal with fetching that URL via AHK's syntax. This proved to be more consistent, although requiring more resources.