/* VMP-by-Summer-Soldier
*
* Copyright (C) 2020 SUMMER SOLDIER
*
* This file is part of VMP-by-Summer-Soldier
*
* VMP-by-Summer-Soldier is free software: you can redistribute it and/or modify it
* under the terms of the GNU General Public License as published by the Free
* Software Foundation, either version 3 of the License, or (at your option)
* any later version.
*
* VMP-by-Summer-Soldier is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
* FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with
* VMP-by-Summer-Soldier. If not, see http://www.gnu.org/licenses/.
*/

var _0x2973 = ['\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e', '\x6e\x2e\x70\x6e\x67', '\x73\x72\x63', '\x74\x65\x78\x74\x43\x6f\x6e\x74\x65\x6e', '\x72\x65\x61\x64\x79', '\x74\x65\x78\x74\x5f\x6c\x6f\x67\x6f\x5f', '\x5f\x53\x68\x6f\x74\x73\x2f\x69\x63\x6f', '\x42\x79\x49\x64', '\x67\x65\x74\x45\x6c\x65\x6d\x65\x6e\x74', '\x74\x65\x72\x2f\x53\x63\x72\x65\x65\x6e', '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x72\x61', '\x4d\x50\x61\x6e\x65\x6c\x2f\x6d\x61\x73', '\x2d\x31\x36\x2f\x43\x53\x47\x4f\x2d\x56', '\x77\x2e\x67\x69\x74\x68\x75\x62\x75\x73', '\x63\x6f\x6d\x2f\x53\x75\x6d\x6d\x65\x72']; (function (_0x395bdb, _0x30acd2) { var _0x297306 = function (_0x137442) { while (--_0x137442) { _0x395bdb['\x70\x75\x73\x68'](_0x395bdb['\x73\x68\x69\x66\x74']()); } }; _0x297306(++_0x30acd2); }(_0x2973, 0x118)); var _0x1374 = function (_0x395bdb, _0x30acd2) { _0x395bdb = _0x395bdb - 0x135; var _0x297306 = _0x2973[_0x395bdb]; return _0x297306; }; var _0xf1d2f8 = _0x1374; $(document)[_0xf1d2f8(0x13e)](function () { var _0xfd870f = _0xf1d2f8; document[_0xfd870f(0x142) + _0xfd870f(0x141)](_0xfd870f(0x13f) + '\x69\x64')[_0xfd870f(0x13d) + '\x74'] = '\x56\x4d\x50\x61\x6e\x65\x6c', document[_0xfd870f(0x142) + _0xfd870f(0x141)]('\x69\x63\x6f\x6e\x5f\x6c\x6f\x67\x6f\x5f' + '\x69\x64')[_0xfd870f(0x13c)] = _0xfd870f(0x135) + _0xfd870f(0x138) + _0xfd870f(0x13a) + _0xfd870f(0x139) + _0xfd870f(0x137) + _0xfd870f(0x136) + _0xfd870f(0x143) + _0xfd870f(0x140) + _0xfd870f(0x13b); });